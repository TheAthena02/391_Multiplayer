<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>
    <form method="POST" action="">
        <label for="identifier">Username or Email:</label>
        <input type="text" id="identifier" name="identifier" required>
        <br><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
        <br><br>
        <button type="submit">Login</button>
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Database connection details
        $servername = "localhost";
        $username = "root";
        $password = "Pickaxe16";
        $dbname = "kickbackplayerdata";

        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);

        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Get form input
        $input_identifier = $_POST['identifier'];
        $input_password = $_POST['password'];

        // Call the stored procedure
        $sql = "CALL LoginUser(?, ?, @login_status)";
        $stmt = mysqli_prepare($conn, $sql);

        if ($stmt) {
            // Bind parameters
            mysqli_stmt_bind_param($stmt, "ss", $input_identifier, $input_password);

            // Execute the statement
            mysqli_stmt_execute($stmt);

            // Fetch the output parameter
            $result = mysqli_query($conn, "SELECT @login_status AS login_status");
            if ($result) {
                $row = mysqli_fetch_assoc($result);
                $login_status = $row['login_status'];
            
                if ($login_status === 'Login successful') {
                    // Redirect to user_info.php with the identifier as a query parameter
                    header("Location: user_info.php?identifier=" . urlencode($input_identifier));
                    exit();
                } else {
                    echo "<p>Login Status: " . htmlspecialchars($login_status) . "</p>";
                }
            } else {
                echo "<p>Failed to retrieve login status.</p>";
            }

            // Close the statement
            mysqli_stmt_close($stmt);
        } else {
            echo "<p>Error preparing statement: " . mysqli_error($conn) . "</p>";
        }

        // Close the connection
        mysqli_close($conn);
    }
    ?>
</body>
</html>