<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
</head>
<body>
    <h1>Welcome to Kickback Portal</h1>
    <nav>
        <ul>
            <li><a href="leaderboard.php">Leaderboard</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="new_user.php">Create New User</a></li>
            <li><a href="gameData.php">New Game Data Entry</a></li>
            <li><a href="all_data.php">All Data</a></li>
        </ul>
    </nav>
</body>
</html>