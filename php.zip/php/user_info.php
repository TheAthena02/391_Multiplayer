<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Information</title>
</head>
<body>
    <a href="home.php">< Home</a>
    <h1>User Information</h1>

    <?php
    // Database connection details
    $servername = "localhost";
    $username = "root";
    $password = "Pickaxe16";
    $dbname = "kickbackplayerdata";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Handle delete request
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user'])) {
        $user_id = $_POST['user_id'];

        // Delete the user and their leaderboard entry
        $sql_delete_user = "DELETE FROM user WHERE id = ?";
        $sql_delete_leaderboard = "DELETE FROM leaderboard WHERE id = ?";

        $stmt_delete_user = mysqli_prepare($conn, $sql_delete_user);
        $stmt_delete_leaderboard = mysqli_prepare($conn, $sql_delete_leaderboard);

        if ($stmt_delete_user && $stmt_delete_leaderboard) {
            mysqli_stmt_bind_param($stmt_delete_user, "i", $user_id);
            mysqli_stmt_bind_param($stmt_delete_leaderboard, "i", $user_id);

            mysqli_stmt_execute($stmt_delete_leaderboard);
            mysqli_stmt_execute($stmt_delete_user);

            echo "<p>User and their leaderboard data have been deleted successfully.</p>";
            mysqli_stmt_close($stmt_delete_user);
            mysqli_stmt_close($stmt_delete_leaderboard);

            // Close the connection and exit
            mysqli_close($conn);
            exit();
        } else {
            echo "<p>Error deleting user: " . mysqli_error($conn) . "</p>";
        }
    }

    // Get the identifier from the query parameter
    if (isset($_GET['identifier'])) {
        $identifier = $_GET['identifier'];

        // Fetch user information
        $sql_user = "SELECT id, username, email, tagline, country, created_at FROM user WHERE username = ? OR email = ?";
        $stmt_user = mysqli_prepare($conn, $sql_user);

        if ($stmt_user) {
            // Bind parameters
            mysqli_stmt_bind_param($stmt_user, "ss", $identifier, $identifier);

            // Execute the statement
            mysqli_stmt_execute($stmt_user);

            // Get the result
            $result_user = mysqli_stmt_get_result($stmt_user);

            if ($row_user = mysqli_fetch_assoc($result_user)) {
                echo "<p><strong>ID:</strong> " . htmlspecialchars($row_user['id']) . "</p>";
                echo "<p><strong>Username:</strong> " . htmlspecialchars($row_user['username']) . "</p>";
                echo "<p><strong>Email:</strong> " . htmlspecialchars($row_user['email']) . "</p>";
                echo "<p><strong>Tagline:</strong> " . htmlspecialchars($row_user['tagline']) . "</p>";
                echo "<p><strong>Country:</strong> " . htmlspecialchars($row_user['country']) . "</p>";
                echo "<p><strong>Created At:</strong> " . htmlspecialchars($row_user['created_at']) . "</p>";

                // Add a delete button
                echo '<form method="POST" action="">';
                echo '<input type="hidden" name="user_id" value="' . htmlspecialchars($row_user['id']) . '">';
                echo '<button type="submit" name="delete_user">Delete User</button>';
                echo '</form>';
            } else {
                echo "<p>No user information found.</p>";
            }

            // Close the statement
            mysqli_stmt_close($stmt_user);
        } else {
            echo "<p>Error preparing statement: " . mysqli_error($conn) . "</p>";
        }

        // Fetch leaderboard information using the stored procedure
        $sql_leaderboard = "CALL get_user_leaderboard(?)";
        $stmt_leaderboard = mysqli_prepare($conn, $sql_leaderboard);

        if ($stmt_leaderboard) {
            // Bind parameters
            mysqli_stmt_bind_param($stmt_leaderboard, "i", $row_user['id']);

            // Execute the statement
            mysqli_stmt_execute($stmt_leaderboard);

            // Get the result
            $result_leaderboard = mysqli_stmt_get_result($stmt_leaderboard);

            if (mysqli_num_rows($result_leaderboard) > 0) {
                echo "<h2>Leaderboard Information</h2>";
                echo "<table border='1'>";
                echo "<tr><th>Kills</th><th>Deaths</th><th>Wins</th><th>Losses</th></tr>";

                while ($row_leaderboard = mysqli_fetch_assoc($result_leaderboard)) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row_leaderboard['kills']) . "</td>";
                    echo "<td>" . htmlspecialchars($row_leaderboard['deaths']) . "</td>";
                    echo "<td>" . htmlspecialchars($row_leaderboard['wins']) . "</td>";
                    echo "<td>" . htmlspecialchars($row_leaderboard['losses']) . "</td>";
                    echo "</tr>";
                }

                echo "</table>";
            } else {
                echo "<p>No leaderboard information found.</p>";
            }

            // Close the statement
            mysqli_stmt_close($stmt_leaderboard);
        } else {
            echo "<p>Error preparing statement: " . mysqli_error($conn) . "</p>";
        }
    } else {
        echo "<p>No identifier provided.</p>";
    }

    // Close the connection
    mysqli_close($conn);
    ?>
</body>
</html>