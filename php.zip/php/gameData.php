<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Game Data</title>
</head>
<body>
    <a href="home.php">< Home</a>
    <h1>Submit Game Data</h1>
    <form method="POST" action="">
        <h2>Player 1</h2>
        <label for="player1_username">Player 1 Username:</label>
        <input type="text" id="player1_username" name="player1_username" required>
        <br><br>
        <label for="player1_kills">Kills:</label>
        <input type="number" id="player1_kills" name="player1_kills" required>
        <br><br>

        <h2>Player 2</h2>
        <label for="player2_username">Player 2 Username:</label>
        <input type="text" id="player2_username" name="player2_username" required>
        <br><br>
        <label for="player2_kills">Kills:</label>
        <input type="number" id="player2_kills" name="player2_kills" required>
        <br><br>

        <button type="submit">Submit</button>
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Database connection details
        $servername = "localhost";
        $username = "root";
        $password = "Pickaxe16";
        $dbname = "kickbackplayerdata";

        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);

        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Get form input
        $player1_username = $_POST['player1_username'];
        $player1_kills = $_POST['player1_kills'];

        $player2_username = $_POST['player2_username'];
        $player2_kills = $_POST['player2_kills'];

        // Enforce the rule: Player 2's kills = Player 1's deaths, and vice versa
        $player1_deaths = $player2_kills;
        $player2_deaths = $player1_kills;

        // Determine the winner based on kills
        if ($player1_kills > $player2_kills) {
            $winner = 1;
        } elseif ($player2_kills > $player1_kills) {
            $winner = 2;
        } else {
            echo "<p>Error: Both players cannot have the same number of kills. Please adjust the data.</p>";
            mysqli_close($conn);
            exit();
        }

        // Fetch Player 1's ID
        $sql_get_id = "SELECT id FROM user WHERE username = ?";
        $stmt_get_id = mysqli_prepare($conn, $sql_get_id);

        if ($stmt_get_id) {
            // Fetch Player 1's ID
            mysqli_stmt_bind_param($stmt_get_id, "s", $player1_username);
            mysqli_stmt_execute($stmt_get_id);
            $result_get_id = mysqli_stmt_get_result($stmt_get_id);

            if ($row = mysqli_fetch_assoc($result_get_id)) {
                $player1_id = $row['id'];
            } else {
                echo "<p>Error: Player 1 username not found.</p>";
                mysqli_close($conn);
                exit();
            }

            // Fetch Player 2's ID
            mysqli_stmt_bind_param($stmt_get_id, "s", $player2_username);
            mysqli_stmt_execute($stmt_get_id);
            $result_get_id = mysqli_stmt_get_result($stmt_get_id);

            if ($row = mysqli_fetch_assoc($result_get_id)) {
                $player2_id = $row['id'];
            } else {
                echo "<p>Error: Player 2 username not found.</p>";
                mysqli_close($conn);
                exit();
            }

            mysqli_stmt_close($stmt_get_id);

            // Set leaderboard update query
            $sql_update = "UPDATE leaderboard 
                           SET kills = kills + ?, 
                               deaths = deaths + ?, 
                               wins = wins + ?, 
                               losses = losses + ?
                           WHERE id = ?";
            $stmt_update = mysqli_prepare($conn, $sql_update);

            if ($stmt_update) {
                // Player 1's win/loss
                $player1_win = ($winner == 1) ? 1 : 0;
                $player1_loss = ($winner == 2) ? 1 : 0;

                // Bind parameters for Player 1
                mysqli_stmt_bind_param($stmt_update, "iiiii", $player1_kills, $player1_deaths, $player1_win, $player1_loss, $player1_id);
                mysqli_stmt_execute($stmt_update);

                // Player 2's win/loss
                $player2_win = ($winner == 2) ? 1 : 0;
                $player2_loss = ($winner == 1) ? 1 : 0;

                // Bind parameters for Player 2
                mysqli_stmt_bind_param($stmt_update, "iiiii", $player2_kills, $player2_deaths, $player2_win, $player2_loss, $player2_id);
                mysqli_stmt_execute($stmt_update);

                echo "<p>Game data successfully added for both players.</p>";

                // Display the game data in a table
                echo "<h2>Game Summary</h2>";
                echo "<table border='1'>";
                echo "<tr><th>Player</th><th>Kills</th><th>Deaths</th><th>Result</th></tr>";
                echo "<tr>";
                echo "<td>" . htmlspecialchars($player1_username) . "</td>";
                echo "<td>" . htmlspecialchars($player1_kills) . "</td>";
                echo "<td>" . htmlspecialchars($player1_deaths) . "</td>";
                echo "<td>" . ($winner == 1 ? "Winner" : "Loser") . "</td>";
                echo "</tr>";
                echo "<tr>";
                echo "<td>" . htmlspecialchars($player2_username) . "</td>";
                echo "<td>" . htmlspecialchars($player2_kills) . "</td>";
                echo "<td>" . htmlspecialchars($player2_deaths) . "</td>";
                echo "<td>" . ($winner == 2 ? "Winner" : "Loser") . "</td>";
                echo "</tr>";
                echo "</table>";

                // Close the statement
                mysqli_stmt_close($stmt_update);
            } else {
                echo "<p>Error preparing update statement: " . mysqli_error($conn) . "</p>";
            }
        } else {
            echo "<p>Error preparing ID fetch statement: " . mysqli_error($conn) . "</p>";
        }

        // Close the connection
        mysqli_close($conn);
    }
    ?>
</body>
</html>