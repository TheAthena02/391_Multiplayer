<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leaderboard</title>
</head>
<body>
    <a href="home.php">< Home</a>
    <h1>Leaderboard</h1>

    <?php
    // Database connection details
    $servername = "localhost";
    $username = "root";
    $password = "Pickaxe16";
    $dbname = "kickbackplayerdata";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Call the stored procedure to fetch sorted leaderboard information
    $sql_leaderboard = "CALL get_user_leaderboard_sorted()";
    $result_leaderboard = mysqli_query($conn, $sql_leaderboard);

    if ($result_leaderboard && mysqli_num_rows($result_leaderboard) > 0) {
        echo "<table border='1'>";
        echo "<tr><th>Username</th><th>Country</th><th>Kills</th><th>Deaths</th><th>Wins</th><th>Losses</th><th>Win/Loss Ratio</th></tr>";

        while ($row = mysqli_fetch_assoc($result_leaderboard)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['username']) . "</td>";
            echo "<td>" . htmlspecialchars($row['country']) . "</td>";
            echo "<td>" . htmlspecialchars($row['kills']) . "</td>";
            echo "<td>" . htmlspecialchars($row['deaths']) . "</td>";
            echo "<td>" . htmlspecialchars($row['wins']) . "</td>";
            echo "<td>" . htmlspecialchars($row['losses']) . "</td>";
            echo "<td>" . htmlspecialchars(number_format($row['win_loss_ratio'], 2)) . "</td>";
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "<p>No leaderboard information found.</p>";
    }

    // Close the connection
    mysqli_close($conn);
    ?>
</body>
</html>