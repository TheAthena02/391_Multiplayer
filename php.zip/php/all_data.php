
<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "Pickaxe16";
$dbname = "kickbackplayerdata";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die(json_encode(["error" => "Connection failed: " . mysqli_connect_error()]));
}

// Initialize an array to store all data
$all_data = [];

// Fetch data from the `user` table
$sql_user = "SELECT * FROM user";
$result_user = mysqli_query($conn, $sql_user);

if ($result_user) {
    $all_data['users'] = mysqli_fetch_all($result_user, MYSQLI_ASSOC);
} else {
    $all_data['users'] = ["error" => "Error fetching user data: " . mysqli_error($conn)];
}

// Fetch data from the `leaderboard` table
$sql_leaderboard = "SELECT * FROM leaderboard";
$result_leaderboard = mysqli_query($conn, $sql_leaderboard);

if ($result_leaderboard) {
    $all_data['leaderboard'] = mysqli_fetch_all($result_leaderboard, MYSQLI_ASSOC);
} else {
    $all_data['leaderboard'] = ["error" => "Error fetching leaderboard data: " . mysqli_error($conn)];
}

// Output the data as JSON
header('Content-Type: application/json');
echo json_encode($all_data, JSON_PRETTY_PRINT);

// Close the connection
mysqli_close($conn);
?>

